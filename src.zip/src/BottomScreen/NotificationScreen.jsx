import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const NotificationScreen = () => {
  return (
    <View>
      <Text>NotificationScreen</Text>
    </View>
  )
}

export default NotificationScreen

const styles = StyleSheet.create({})