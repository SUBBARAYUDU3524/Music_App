export default {
  JAMENDO_CLIENT_ID: '97ab15f5', // Register at https://developer.jamendo.com/
  JAMENDO_API_URL: 'https://api.jamendo.com/v3.0',
  FIREBASE_CONFIG: {
    apiKey: 'YOUR_API_KEY',
    authDomain: 'YOUR_AUTH_DOMAIN',
    projectId: 'YOUR_PROJECT_ID',
    storageBucket: 'YOUR_STORAGE_BUCKET',
    messagingSenderId: 'YOUR_SENDER_ID',
    appId: 'YOUR_APP_ID',
  },
};
